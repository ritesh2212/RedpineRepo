High Level IR :
    - compuatationalGraphLenet.png
Low Level IR
    - lenetIR.txt
Node Lowered IR
    - LenetNodeLowered.pdf
Dump IR  - Prints IR to stdout
    - lenetLowLevelIR.txt
IR After Every 79 Optimization passes:
    - after-opt
IR Before Every 79 Optimization passes:
    - before-opt
